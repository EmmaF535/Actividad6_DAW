<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Apps\Models\divisions;

class divisionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $division = new \App\Models\divisions;
        $division->division_name = "AFC North";
        $division->sb_titles_division = 5;
        $division->save();

        $division = new \App\Models\divisions;
        $division->division_name = "AFC South";
        $division->sb_titles_division = 2;
        $division->save();

        $division = new \App\Models\divisions;
        $division->division_name = "AFC West";
        $division->sb_titles_division = 3;
        $division->save();

        $division = new \App\Models\divisions;
        $division->division_name = "AFC East";
        $division->sb_titles_division = 1;
        $division->save();

        $division = new \App\Models\divisions;
        $division->division_name = "NFC North";
        $division->sb_titles_division = 2;
        $division->save();

        $division = new \App\Models\divisions;
        $division->division_name = "NFC South";
        $division->sb_titles_division = 4;
        $division->save();

        $division = new \App\Models\divisions;
        $division->division_name = "NFC West";
        $division->sb_titles_division = 2;
        $division->save();

        $division = new \App\Models\divisions;
        $division->division_name = "NFC East";
        $division->sb_titles_division = 1;
        $division->save();
    }
}
