<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\conferencesController;
use App\Http\Controllers\teamsController;
use App\Http\Controllers\citiesController;
use App\Http\Controllers\divisionsController;

Route::get('/', function () {
    return view('welcome');
});

Route::resource('/conferences', conferencesController::class);
Route::resource('/teams', teamsController::class);
Route::resource('/divisions', divisionsController::class);
Route::resource('/cities', citiesController::class);
