# Release Notes

## [Unreleased](https://github.com/laravel/laravel/compare/v11.0.0...11.x)

## [v11.0.0 (2023-02-17)](https://github.com/laravel/laravel/compare/v10.3.2...v11.0.0)

Laravel 11 includes a variety of changes to the application skeleton. Please consult the diff to see what's new.
