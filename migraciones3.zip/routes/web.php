<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\conferencesController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
|  127.0.0.1:8000/conferences
*/

Route::get('/', function () {
    return view('welcome');
});



Route::resource('/conferences', conferencesController::class);
Route::resource('/teams', teamController::class);
Route::resource('/divisions', divisionController::class);
Route::resource('/cities', citiesController::class);
