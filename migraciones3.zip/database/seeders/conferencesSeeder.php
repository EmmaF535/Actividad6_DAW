<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\conferences;

class conferencesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        $conferencia = new conferences;
        $conferencia->conference_name = "American Football Conference";
        $conferencia->conference_logo = "asdkfjaiosjf";
        $conferencia->sb_titles_conference = 30;
        $conferencia->save();

        $conferencia = new conferences;
        $conferencia->conference_name = "National Football Conference";
        $conferencia->conference_logo = "fh9euhfjdvsid";
        $conferencia->sb_titles_conference = 30;
        $conferencia->save();
    }
}
